<?php
$db=new mysqli("localhost","root","","hms") or die(mysqli_error());




?>